/*
 * CineVerse frontend.
 * 1) Get a TMDB v3 API key: https://www.themoviedb.org/settings/api
 * 2) Paste it into TMDB_API_KEY below.
 * This is a public frontend key: anyone can view it in browser source.
 */
const TMDB_API_KEY = "PASTE_YOUR_TMDB_V3_API_KEY_HERE";
const API_BASE = "https://api.themoviedb.org/3";
const IMAGE_BASE = "https://image.tmdb.org/t/p/";
const POSTER_SIZE = "w500";
const BACKDROP_SIZE = "w1280";

const state = {
  view: "trending",
  page: 1,
  totalPages: 1,
  genre: null,
  query: "",
  currentHero: null,
  currentDetails: null,
  searchTimer: null
};

const els = {
  hero: document.querySelector("#hero"),
  heroTitle: document.querySelector("#heroTitle"),
  heroOverview: document.querySelector("#heroOverview"),
  heroMeta: document.querySelector("#heroMeta"),
  heroDetails: document.querySelector("#heroDetails"),
  heroTrailer: document.querySelector("#heroTrailer"),
  search: document.querySelector("#searchInput"),
  clearSearch: document.querySelector("#clearSearch"),
  heading: document.querySelector("#pageHeading"),
  status: document.querySelector("#status"),
  genreBar: document.querySelector("#genreBar"),
  grid: document.querySelector("#resultsGrid"),
  loadMore: document.querySelector("#loadMore"),
  playerSection: document.querySelector("#playerSection"),
  playerTitle: document.querySelector("#playerTitle"),
  playerFrame: document.querySelector("#playerFrame"),
  closePlayer: document.querySelector("#closePlayer"),
  modal: document.querySelector("#detailsModal"),
  closeDetails: document.querySelector("#closeDetails"),
  detailsBackdrop: document.querySelector("#detailsBackdrop"),
  detailsType: document.querySelector("#detailsType"),
  detailsTitle: document.querySelector("#detailsTitle"),
  detailsMeta: document.querySelector("#detailsMeta"),
  detailsOverview: document.querySelector("#detailsOverview"),
  detailsTrailer: document.querySelector("#detailsTrailer"),
  legalFreeSearch: document.querySelector("#legalFreeSearch")
};

const genreLists = {
  movie: [
    { id: 28, name: "Action" }, { id: 12, name: "Adventure" }, { id: 16, name: "Animation" },
    { id: 35, name: "Comedy" }, { id: 80, name: "Crime" }, { id: 18, name: "Drama" },
    { id: 14, name: "Fantasy" }, { id: 27, name: "Horror" }, { id: 10749, name: "Romance" },
    { id: 878, name: "Sci-Fi" }, { id: 53, name: "Thriller" }
  ],
  tv: [
    { id: 10759, name: "Action & Adventure" }, { id: 16, name: "Animation" }, { id: 35, name: "Comedy" },
    { id: 80, name: "Crime" }, { id: 18, name: "Drama" }, { id: 9648, name: "Mystery" },
    { id: 10765, name: "Sci-Fi & Fantasy" }, { id: 10768, name: "War & Politics" }
  ]
};

function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}
function titleOf(item) { return item.title || item.name || "Untitled"; }
function dateOf(item) { return item.release_date || item.first_air_date || ""; }
function yearOf(item) { return dateOf(item).slice(0, 4) || "Year unknown"; }
function mediaTypeOf(item) { return item.media_type || (item.first_air_date ? "tv" : "movie"); }
function posterUrl(path, size = POSTER_SIZE) { return path ? `${IMAGE_BASE}${size}${path}` : ""; }

async function api(path, params = {}) {
  if (!TMDB_API_KEY || TMDB_API_KEY.includes("PASTE_YOUR")) {
    throw new Error("Add your TMDB API key in script.js before using the app.");
  }
  const url = new URL(`${API_BASE}${path}`);
  url.searchParams.set("api_key", TMDB_API_KEY);
  url.searchParams.set("language", "en-US");
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") url.searchParams.set(key, value);
  });
  const response = await fetch(url);
  if (!response.ok) {
    if (response.status === 401) throw new Error("TMDB rejected the API key. Check it in script.js.");
    if (response.status === 429) throw new Error("Too many requests. Wait a moment and try again.");
    throw new Error(`TMDB request failed (${response.status}).`);
  }
  return response.json();
}

function setStatus(message) { els.status.textContent = message; }
function headingForView() {
  if (state.query) return `Search results for “${state.query}”`;
  if (state.genre) {
    const genres = [...genreLists.movie, ...genreLists.tv];
    return genres.find(g => g.id === state.genre)?.name || "Filtered titles";
  }
  return ({
    trending: "Trending this week", movie: "Popular Movies",
    tv: "Popular TV Series", top_rated: "Top Rated"
  })[state.view] || "Discover";
}
function buildEndpoint() {
  if (state.query) return ["/search/multi", { query: state.query, page: state.page, include_adult: false }];
  if (state.genre) {
    const media = state.view === "tv" ? "tv" : "movie";
    return [`/discover/${media}`, { with_genres: state.genre, sort_by: "popularity.desc", page: state.page }];
  }
  const routes = {
    trending: ["/trending/all/week", { page: state.page }],
    movie: ["/movie/popular", { page: state.page }],
    tv: ["/tv/popular", { page: state.page }],
    top_rated: ["/movie/top_rated", { page: state.page }]
  };
  return routes[state.view];
}

async function loadTitles({ append = false } = {}) {
  els.heading.textContent = headingForView();
  els.loadMore.hidden = true;
  setStatus("Loading titles…");
  if (!append) els.grid.innerHTML = "";
  try {
    const [path, params] = buildEndpoint();
    const data = await api(path, params);
    const results = (data.results || []).filter(item => item.media_type !== "person");
    state.totalPages = Math.min(data.total_pages || 1, 500);
    renderCards(results, append);
    setStatus(results.length ? `${data.total_results?.toLocaleString() || results.length} titles found` : "No titles found.");
    els.loadMore.hidden = state.page >= state.totalPages || results.length === 0;
    if (!results.length && !append) {
      els.grid.innerHTML = '<p class="empty-state">No results. Try another search or genre.</p>';
    }
    if (!append && !state.query && !state.genre && results.length) {
      const featured = results.find(item => item.backdrop_path) || results[0];
      if (!state.currentHero || state.view !== "trending") setHero(featured);
    }
  } catch (error) {
    setStatus(error.message);
    if (!append) els.grid.innerHTML = `<p class="empty-state">${escapeHTML(error.message)}</p>`;
  }
}

function renderCards(items, append) {
  const html = items.map(item => {
    const media = mediaTypeOf(item);
    const poster = posterUrl(item.poster_path);
    return `<article class="movie-card" tabindex="0" role="button" aria-label="Details for ${escapeHTML(titleOf(item))}" data-id="${Number(item.id)}" data-type="${escapeHTML(media)}">
      <div class="poster-wrap">
        ${poster ? `<img class="poster" src="${poster}" alt="${escapeHTML(titleOf(item))} poster" loading="lazy" onerror="this.outerHTML='<div class=&quot;poster-fallback&quot;>No poster available</div>'">` : '<div class="poster-fallback">No poster available</div>'}
        <span class="rating">★ ${Number(item.vote_average || 0).toFixed(1)}</span>
        <span class="card-type">${media === "tv" ? "Series" : "Movie"}</span>
      </div>
      <h3 class="card-title" title="${escapeHTML(titleOf(item))}">${escapeHTML(titleOf(item))}</h3>
      <p class="card-meta">${escapeHTML(yearOf(item))}</p>
    </article>`;
  }).join("");
  if (append) els.grid.insertAdjacentHTML("beforeend", html);
  else els.grid.innerHTML = html;
}

function setHero(item) {
  state.currentHero = item;
  const title = titleOf(item);
  els.heroTitle.textContent = title;
  els.heroOverview.textContent = item.overview || "Discover more about this title.";
  els.heroMeta.textContent = `${mediaTypeOf(item) === "tv" ? "TV SERIES" : "MOVIE"}  ·  ${yearOf(item)}  ·  ★ ${Number(item.vote_average || 0).toFixed(1)}`;
  const backdrop = item.backdrop_path ? posterUrl(item.backdrop_path, BACKDROP_SIZE) : "";
  els.hero.style.backgroundImage = backdrop ? `url("${backdrop}")` : "linear-gradient(110deg, #19152a, #090b10)";
  els.heroDetails.onclick = () => openDetails(item.id, mediaTypeOf(item));
  els.heroTrailer.onclick = () => playTrailer(item.id, mediaTypeOf(item), title);
}

function renderGenres() {
  const list = state.view === "tv" ? genreLists.tv : genreLists.movie;
  els.genreBar.innerHTML = `<button class="genre-chip ${state.genre === null ? "active" : ""}" data-genre="">All genres</button>` +
    list.map(g => `<button class="genre-chip ${state.genre === g.id ? "active" : ""}" data-genre="${g.id}">${escapeHTML(g.name)}</button>`).join("");
  els.genreBar.hidden = Boolean(state.query) || state.view === "trending" || state.view === "top_rated";
}

async function openDetails(id, media) {
  try {
    const item = await api(`/${media}/${id}`, { append_to_response: "videos" });
    state.currentDetails = { ...item, media_type: media };
    els.detailsType.textContent = media === "tv" ? "TV SERIES" : "MOVIE";
    els.detailsTitle.textContent = titleOf(item);
    els.detailsMeta.textContent = `${yearOf(item)}  ·  ★ ${Number(item.vote_average || 0).toFixed(1)}  ·  ${(item.genres || []).map(g => g.name).join(" / ")}`;
    els.detailsOverview.textContent = item.overview || "No synopsis is available.";
    const backdrop = item.backdrop_path ? posterUrl(item.backdrop_path, BACKDROP_SIZE) : "";
    els.detailsBackdrop.style.backgroundImage = backdrop ? `url("${backdrop}")` : "linear-gradient(120deg,#29203d,#11151e)";
    els.detailsTrailer.onclick = () => playTrailer(id, media, titleOf(item));
    // These links help users find legitimate free/public-domain options.
    // Availability and licensing must be verified on the destination service.
    const searchTitle = titleOf(item);
    els.legalFreeSearch.href = `https://archive.org/search?query=${encodeURIComponent(searchTitle + " AND mediatype:movies")}`;
    els.modal.hidden = false;
    document.body.style.overflow = "hidden";
  } catch (error) { setStatus(error.message); }
}
function closeDetails() {
  els.modal.hidden = true;
  document.body.style.overflow = "";
}

async function playTrailer(id, media, title) {
  try {
    const data = await api(`/${media}/${id}/videos`);
    const videos = data.results || [];
    const video = videos.find(v => v.site === "YouTube" && v.type === "Trailer" && v.key) ||
      videos.find(v => v.site === "YouTube" && v.key);
    if (!video) {
      setStatus("No official YouTube trailer is listed for this title.");
      return;
    }
    // YouTube embed is used for official videos; no unlicensed full-movie sources are hardcoded.
    els.playerTitle.textContent = `${title} — ${video.name || "Trailer"}`;
    els.playerFrame.innerHTML = `<iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(video.key)}?autoplay=1&rel=0" title="${escapeHTML(title)} trailer" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`;
    els.playerSection.hidden = false;
    closeDetails();
    els.playerSection.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) { setStatus(error.message); }
}
function closePlayer() {
  els.playerFrame.innerHTML = ""; // Stop playback when closing.
  els.playerSection.hidden = true;
}

function changeView(view) {
  state.view = view;
  state.page = 1;
  state.genre = null;
  state.query = "";
  state.currentHero = null;
  els.search.value = "";
  els.clearSearch.hidden = true;
  document.querySelectorAll(".nav-link").forEach(button => button.classList.toggle("active", button.dataset.view === view));
  renderGenres();
  loadTitles();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.querySelectorAll(".nav-link").forEach(button => button.addEventListener("click", () => changeView(button.dataset.view)));
els.genreBar.addEventListener("click", event => {
  const button = event.target.closest("[data-genre]");
  if (!button) return;
  state.genre = button.dataset.genre ? Number(button.dataset.genre) : null;
  state.page = 1;
  renderGenres();
  loadTitles();
});
els.grid.addEventListener("click", event => {
  const card = event.target.closest(".movie-card");
  if (card) openDetails(card.dataset.id, card.dataset.type);
});
els.grid.addEventListener("keydown", event => {
  if ((event.key === "Enter" || event.key === " ") && event.target.matches(".movie-card")) {
    event.preventDefault();
    openDetails(event.target.dataset.id, event.target.dataset.type);
  }
});
els.search.addEventListener("input", () => {
  clearTimeout(state.searchTimer);
  const value = els.search.value.trim();
  els.clearSearch.hidden = !value;
  state.searchTimer = setTimeout(() => {
    state.query = value;
    state.page = 1;
    state.genre = null;
    renderGenres();
    loadTitles();
  }, 350); // Debounce requests while the user types.
});
els.clearSearch.addEventListener("click", () => {
  els.search.value = "";
  els.clearSearch.hidden = true;
  state.query = "";
  state.page = 1;
  renderGenres();
  loadTitles();
  els.search.focus();
});
els.loadMore.addEventListener("click", () => { state.page += 1; loadTitles({ append: true }); });
els.closePlayer.addEventListener("click", closePlayer);
els.closeDetails.addEventListener("click", closeDetails);
els.modal.addEventListener("click", event => { if (event.target.dataset.close) closeDetails(); });
document.addEventListener("keydown", event => {
  if (event.key === "Escape") { closeDetails(); closePlayer(); }
});

renderGenres();
loadTitles();
