# CineVerse

A responsive, static movie and TV discovery website built with HTML, CSS, and vanilla JavaScript using TMDB's API.

## Files
- `index.html` — page structure
- `style.css` — responsive dark UI
- `script.js` — TMDB requests, search, genres, details, and official trailer embeds

## Setup
1. Create a TMDB account and request a v3 API key at https://www.themoviedb.org/settings/api
2. Open `script.js` and replace `PASTE_YOUR_TMDB_V3_API_KEY_HERE` with your key.
3. Upload all three files to the root of a GitHub repository.
4. In GitHub, open Settings → Pages → Build and deployment → Deploy from a branch.
5. Select `main` and `/ (root)`, then Save. Wait for the published URL shown on that page.

## Notes
- This is a static frontend; the browser can see the TMDB API key. Do not put private credentials in this repository.
- The player uses official YouTube trailers listed by TMDB. TMDB metadata does not provide full-film playback streams.
- For non-commercial use, follow TMDB's current API terms and attribution requirements. This product uses the TMDB API but is not endorsed or certified by TMDB.

## Legal free viewing
The title details modal includes a link to search Internet Archive for potentially free/public-domain material. This is a search shortcut, not a guarantee that a matching title is available or legally streamable. Check the rights and terms on each item before watching or linking it. Availability varies by region.
